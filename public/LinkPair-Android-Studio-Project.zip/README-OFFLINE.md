# LinkPair - 100% Offline Standalone Android APK

Diese native Android-App ist **VOLLSTÄNDIG OFFLINE** und **NICHT WEBBASIERT**:
* Sämtliche Programmdateien (React, WebRTC, Tailwind, Icons, Schriften) liegen direkt im Ordner `app/src/main/assets/` in der APK.
* Startet blitzschnell im Flugmodus ohne Internet.
* P2P-Verbindungen laufen lokal von Gerät zu Gerät.

## 🚀 Wie erstelle ich die APK daraus?
1. **Mit Android Studio (Kostenlos)**:
   - Öffnen Sie Android Studio -> "Open" -> Wählen Sie diesen entpackten Ordner.
   - Klicken Sie im Menü auf **Build** -> **Build APK(s)**.
   - Fertig! Die APK liegt unter `app/build/outputs/apk/debug/app-debug.apk`.

2. **Mit GitHub Actions (Vollautomatisch ohne Android Studio auf dem PC)**:
   - Projekt auf GitHub hochladen -> Unter "Actions" wird die APK in 2 Minuten kostenlos kompiliert!

Built with love - Jude ❤️
